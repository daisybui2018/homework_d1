package com.onemount.DataStructure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataStructureApplicationTests {

	@Test
	void contextLoads() {
	}

}
